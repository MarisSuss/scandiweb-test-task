<?php

namespace Src\Models;

class Attribute {
    public string $id;
    public string $value;
    public string $displayValue;
}
